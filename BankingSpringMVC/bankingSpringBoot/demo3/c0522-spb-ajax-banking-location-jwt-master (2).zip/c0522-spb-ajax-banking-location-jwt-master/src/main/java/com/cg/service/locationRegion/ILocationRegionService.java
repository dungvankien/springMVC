package com.cg.service.locationRegion;

import com.cg.model.LocationRegion;
import com.cg.service.IGeneralService;

public interface ILocationRegionService extends IGeneralService<LocationRegion> {
}
