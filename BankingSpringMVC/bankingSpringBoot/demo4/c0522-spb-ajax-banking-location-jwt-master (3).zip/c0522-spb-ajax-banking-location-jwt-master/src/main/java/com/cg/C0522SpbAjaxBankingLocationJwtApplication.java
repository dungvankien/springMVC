package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C0522SpbAjaxBankingLocationJwtApplication {

    public static void main(String[] args) {
        SpringApplication.run(C0522SpbAjaxBankingLocationJwtApplication.class, args);
        System.out.println("Application is running.......");
    }

}
