package com.cg.model;

public class Withdraw {
}
